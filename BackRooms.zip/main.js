var canvas = document.getElementById("canvas")
var ctx = canvas.getContext("2d")
var object = document.getElementById("object")


var x = 250
var y = 280
var dx = 15
var dy = -6
var floppa = new Image()
floppa.src="floppus.png"
floppa.addEventListener("load", () => {
 ctx.drawImage(floppa, x,y,110,110)
})
var Home = new Image()
Home.src = "Home.png"
Home.addEventListener("load", () => {
 ctx.drawImage(Home, 0, 0, canvas.width, canvas.height)
})

let cry_floppa = new Image()
cry_floppa.src = "floppus.png"
cry_floppa.addEventListener("load", () => {
 ctx.drawImage(cry_floppa, 900, 280, 110, 110)
})

let bingus_x = 0
let bingus_y = 280
let bingus_dx = 2

let bingus_x1 = 0
let bingus_y1 = 280
let bingus_dx1 = 2

function loop(){
 ctx.clearRect(0,0,1000,500)
 bingus_x += bingus_dx
 ctx.drawImage(Home, 0, 0, 1000, 500)
 ctx.drawImage(bingus, bingus_x, bingus_y, 90, 90)
 ctx.drawImage(floppa, x, y, 110, 110)
 ctx.drawImage(cry_floppa, 900, 280, 110, 110)

 if (bingus_x + bingus_dx > canvas.width) {
  object.innerHTML = " НОООО.Вы не защитили шлёпу"
  ctx.clearRect(0,0,1000,500)
}

}

var bingus = new Image()
bingus.src = "bingus.png"
bingus.addEventListener("load", () => {
 ctx.drawImage(bingus, bingus_x, bingus_y, 90, 90)
})

var bingus1 = new Image()
bingus1.src = "bingus.png"
bingus.addEventListener("load", () => {
 ctx.drawImage(bingus1, bingus_x, bingus_y, 110, 110)
})

let go = 0
canvas.addEventListener("keydown", (event)=>{
 if (event.keyCode == 39){
  
  ctx.clearRect(x, y, 110, 110)
  x += dx
  ctx.drawImage(Home, 0, 0, 1000, 500)
  ctx.drawImage(floppa, x, y, 110, 110)
  ctx.drawImage(bingus, bingus_x, bingus_y, 90, 90)
  ctx.drawImage(cry_floppa, 900, 280, 110, 110)
 }
 if (event.keyCode == 37) {
  ctx.clearRect(x, y, 110, 110)
  x -= dx
  ctx.drawImage(Home, 0, 0, 1000, 500)
  ctx.drawImage(floppa, x, y, 110, 110)
  ctx.drawImage(bingus, bingus_x, bingus_y, 90, 90)
  ctx.drawImage(cry_floppa, 900, 280, 110, 110)
 }
 if (event.keyCode == 40){
  ctx.clearRect(0,0,1000,500)
  ctx.drawImage(Home, 0, 0, 1000, 500)
  ctx.drawImage(floppa, x, y, 110, 110)
  if (x+dx > bingus_x+bingus_dx){
   bingus_x -= 40
   ctx.drawImage(bingus, bingus_x, bingus_y, 90, 90)
   ctx.drawImage(cry_floppa, 900, 280, 110, 110)
  }
 }
}
)

setInterval(loop, 10)